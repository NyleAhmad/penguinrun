
function preload() {
  //Penguin pics
  Peng1 = loadImage("walk-0.png");
  Peng2 = loadImage("walk-1 (1).png");
  Peng3 = loadImage("walk-2 (1).png");
  Peng4 = loadImage("walk-3 (1).png");
  Peng5 = loadImage("walk-4 (1).png");
  Peng6 = loadImage("walk-5 (1).png");
  Peng7 = loadImage("walk-7 (1).png");
  //Background pic
  mainbackground = loadImage("mainbackground.jpg");
  mainbackground2 = loadImage("vecteezy_alien-planet-game-background_6316482.jpg");
  //Enemy pics
  Badguy1 = loadImage("L1E.png");
  Badguy2 = loadImage("L2E.png");
  Badguy3 = loadImage("L3E.png");
  Badguy4 = loadImage("L6E.png");
  //Coin pics
  coin1 = loadImage("coin.png");
  coin2 = loadImage("coin (1).png");
  coin3 = loadImage("coin (2).png");
  coin4 = loadImage("coin (4).png");
  coin5 = loadImage("coin (5).png");
  coin6 = loadImage("coin (6).png");
  //bullet pic
  bullet1 = loadImage("All_Fire_Bullet_Pixel_16x16.png");
  //sounds
  Bksound = loadSound("Background_Music.mp3");
  sadSound = loadSound("penguindie.mp3");
  jumpSound = loadSound("jumpingsound (1).mp3");
  coinCollectSound = loadSound("collectcoin-6075.mp3");
}

//Empty list
let badguys = [];
let coinlist = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  background("lightblue");
  player = new Player(windowWidth/15, windowHeight * 0.825);
  background1 = new backgrounddd(4);
  showscore = new showScore();
  gameMang = new Game();
  shield = new Shield();
  bullet = new Bullet(player.x - 75, player.y - 20);
  //  Bksound.play();
  
  
  //spawning z amount of badguys
  for(let z = 0; z<5; z++)
    {
      badguys.push(new Enemy(random(350, windowWidth + 320), windowHeight * 0.825));
    }
  
  //spawning c amount of coins
  for(let c = 0; c < random(1, 5); c++)
    {
      coinlist.push(new Coin(random(20, 400), random(windowHeight * .55, windowHeight * 0.825)));
    }
} 
//0.825 * height should be y value for player and enemies on laptop
//0.627 * height should be y value for player and enemies on monitor


function checkBadguyCollisions() {
  for (let i = 0; i < badguys.length; i++) {
    const badguy = badguys[i];
    const distance = dist(badguy.x, badguy.y, player.x, player.y);

    if (distance < (badguy.width + player.width) / 2 && distance < (badguy.height + player.height) / 2) {
      console.log("Enemy collision detected");
      //death screen and resets all scores
      //sadSound.play();
      gameMang.tag = "dead";
    }
  }
}

let coinCollected = 0;
function checkCoinCollisions()
{
  for (let i = 0; i < coinlist.length; i++) {
    const coin = coinlist[i];
    const distance = dist(coin.x, coin.y, player.x, player.y);

    if (distance < (coin.width + player.width) / 2 && distance < (player.height + coin.height) / 2) 
    {
      coinCollectSound.play();
      console.log("Coin collision detected");
      coin.x = mainbackground.width + random(20, 400); 
      coin.y = random(windowHeight * .3, windowHeight * .55);
      coinCollected += 1;
    }
 }
    
}

function checkBulletCollisions() {
  for (let i = 0; i < badguys.length; i++) {
    const badguy = badguys[i];
    const distance = dist(bullet.x - 100, bullet.y, badguy.x, badguy.y);
    
    if (distance < (bullet.width + badguy.width) / 2 && distance < (bullet.height + badguy.height) / 2  && bullet.IsBulletShot == true) {
      console.log("Bullet collision detected");
      badguy.x = random(600, windowWidth + 520);
      bullet.reset();
        

      
    }
  }
}
function keyPressed() {
  if (keyCode === 32 && !player.jumping) {
    player.jumping = true;
    jumpSound.play();
  }
}



    





function draw() {
  gameMang.ScreenMang();
  
}
    
  


