class Game {
  constructor() {
    this.tag = "intro";
  }


  ScreenMang() {
    if (this.tag == "main") {
      this.Main();
    }
    if(this.tag == "intro")
      this.Intro();
    if(this.tag == "dead")
    {
      this.Dead();
    }
  }

  Intro() {
    background('white');
    if(keyIsPressed)
    {
      this.tag = "main";
    }
    text("Penguin run", windowWidth/2.5, windowHeight/2);
  }

  Main() {
    //Bksound.play();
    //background
    background1.update();

    //score going up while not dead
    showscore.score++;
    showscore.display();

    //coins
    for (const coin of coinlist) {
      coin.update();
      coin.display();
      checkCoinCollisions();
    }

    //player
    player.update();
    player.display();

    //shield
    shield.display();

    for (const badguy of badguys) {
      badguy.update();
      badguy.display();
      checkBadguyCollisions();

    }
    //bullet
    bullet.update();
    checkBulletCollisions()

  }

  Dead()
  {
    this.Restart();
    if(keyIsDown(70));
    {
      this.tag = "main";
    }

  }

  Restart()
  {
    //speed resets
    background1.speed = 4;
    
     //coins and num of coins collected resets
    for(const coin of coinlist)
      {
        coin.reset();
      }
    coinCollected = 0;
      //badguys respawn
    for(let p = 0; p< 5; p++)    
      {
        badguys[p].x = random(600, windowWidth + 520);
      }
    showscore.update();
  }

  

}