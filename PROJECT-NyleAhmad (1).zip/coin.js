class Coin
  {
    constructor(x, y)
    {
      this.sprites = [coin1, coin1, coin1, coin2, coin2, coin2, coin3, coin3, coin3, coin4, coin4, coin4, coin5, coin5, coin5, coin6, coin6, coin6];
      
      this.current_pic = 0;
      this.image = this.sprites[this.current_pic];
      
      this.x = x;
      this.y = y;

      this.width = 35;
      this.height = 35;
    }
    
    update()
  {
    //animation loop
    this.current_pic += 1
    if(this.current_pic > 17)
    {
      this.current_pic = 0; 
    }
    
    this.image = this.sprites[this.current_pic];
    
   // Moving left
    this.x -= 2 + background1.speed;

   // respawning after going offscreen
    if(this.x <= -mainbackground.width - 10)
      {
       this.reset();
      }

  }
    display()
  {
    image(this.image, this.x, this.y);
    text("Coins: " + coinCollected, windowWidth - 170, windowHeight * 0.18);
  }
    reset()
    {
      this.x = mainbackground.width + random(20, 400);
      this.y = random(windowHeight * .3, windowHeight * .55);
      this.numOfCoins = 0;
    }
  
  }
  