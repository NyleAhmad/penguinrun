class Bullet
  {
    constructor(x,y)
    {
      this.x = x;
      this.y = y;
      this.width = 6;
      this.height = 4;
      
      this.IsGunReady = true;
      this.IsBulletShot = false;

      this.image = bullet1;
    }

    update()
    {
      if(coinCollected >= 3)
      {
        this.IsGunReady = true;
      }
      if(keyIsDown(70) && this.IsGunReady == true)
      {
        this.shoot();
        this.IsBulletShot = true;
      }
    }

    shoot()
    {
      this.display();
      this.x += 5;
    }

    reset()
    {
      this.IsBulletShot = false;
      this.x = player.x - 75;
      this.y = player.y - 20; 
    }

    display()
    {
      image(bullet1, this.x, this.y);
    }
  }