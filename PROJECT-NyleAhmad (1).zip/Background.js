 class backgrounddd{

  constructor(speed) 
  {
    this.x = 0;
    this.speed = speed;
    this.speed_thresholds = [175, 225, 360, 580, 930, 1050, 1200, 1400, 1550, 1690, 1900, 2100, 2500];
    
    
  }

  update()
  {
    //looping background 
    image(mainbackground, this.x, windowHeight * 0.009);
    image(mainbackground, (mainbackground.width + this.x), windowHeight * 0.009);

    //speeding up over time logic 
    console.log("background Speed is " + this.speed);
    for(let s = 0; s < this.speed_thresholds.length; s++)
      {
        if(showscore.score == this.speed_thresholds[s])
        {
          this.speed += 1;
        }
      }

    //displaying the images
    if(this.x < -mainbackground.width)
    {
      this.x = 0;
      image(mainbackground, (mainbackground.width + this.x), windowHeight * 0.009);
      image(mainbackground, ((mainbackground.width + this.x) * 1), windowHeight * 0.009);
      
    }
    this.x -= this.speed;
  }

  
}


  
