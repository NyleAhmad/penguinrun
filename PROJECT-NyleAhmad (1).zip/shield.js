class Shield
  {
    constructor(x, y)
    {
      this.x = player.x;
      this.y = player.y;

      this.isShieldReady = true;
    }

    display()
    {
      if(this.ShieldReady == true)
      {
        noFill();
        
        ellipse(player.x + 30, player.y + 40, 75);
      }
    }
  }