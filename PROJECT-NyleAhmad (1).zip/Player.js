class Player{

  constructor(x, y) {
    this.animation = true;
    this.jumping = false;
    this.sprites = [Peng1, Peng2, Peng3, Peng4, Peng5, Peng6, Peng7];
		

    this.current_sprite = 0;
    this.image = this.sprites[this.current_sprite];
    
    this.x = x;
    this.y = y;
    this.width = 9;
    this.height = 9;

    
    this.vel = 22;
  }
  walk()
  {
    this.animation = true;
  }



  
  update()
  {
    
    if(this.animation == true)
    {
      this.current_sprite += 1;
     
    }
    //looping animation
    if(this.current_sprite >= 7)
    {
      this.current_sprite = 0;
    }
    //updating image to animate
    this.image = this.sprites[this.current_sprite];

    //jumping physics 
    if(this.jumping == true)
    {
      this.y -= this.vel;
      this.vel -=1;
      if(this.vel < -22)
      { 
        this.jumping = false;
        this.vel = 22;
      }

    
    
    }
  }

  display()
  {
    image(this.image, this.x, this.y);
  }
  


  }
  
