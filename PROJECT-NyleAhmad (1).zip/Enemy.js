class Enemy {

  constructor(x, y)
  {
    this.sprites = [Badguy1, Badguy1, Badguy2, Badguy2, Badguy3, Badguy3, Badguy4, Badguy4];

    this.current_sprite = 0;
    this.image = this.sprites[this.current_sprite];
    
    this.x = x;
    this.y = y;
    this.width = 5;
    this.height = 13;

    //this.rect = rect(this.x-1, this.y, this.x, this.y);
  }

  update()
  {
    //animation loop
    this.current_sprite += 1
    if(this.current_sprite > 7) 
    {
      this.current_sprite = 0; 
    }
    this.image = this.sprites[this.current_sprite];
    
    //Moving left
    this.x -= 5 + background1.speed;

    //respawning after going offscreen
    if(this.x <= -windowWidth)
      {
       this.x = windowWidth + random(8, 50);
      
    
      }
  }

  display()
  {
    image(this.image, this.x, this.y);
  }




  
}