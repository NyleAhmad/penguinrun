 class showScore {
  
  constructor()
  {
    this.scores = [];
    this.score = 0;
    this.highscore = 0;
  }
  
  update() 
  {
    
    console.log("u ded");
    this.scores.push(this.score);
    this.score = 0;
    this.highscore = max(this.scores);

  }
    
  

  display()
  {
    textSize(20); 
    text("Score: " + this.score, windowWidth - 170, windowHeight * 0.08);
    text("High Score: " + this.highscore, windowWidth - 170, windowHeight * 0.13);
    
  }

  
}